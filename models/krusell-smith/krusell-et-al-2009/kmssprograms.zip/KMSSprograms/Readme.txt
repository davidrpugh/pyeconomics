This folder contains the Fortran codes for the paper "Revisiting the Welfare Effects of Eliminating Business Cycles" by Per Krusell, Toshihiko Mukoyama, Aysegul Sahin, and Anthony A. Smith, Jr. 

The programs are divided into two folders. One contains the two-employment-state case, and the other contains the three-employment-state case.  Each contains a subfolder for the benchmark economy with fluctuations and a subfolder for one transition experiment: starting from  (k=11.2 & z=b) for the two-state case and (k=11.3 & z=b) for the three-state case. The input files for the experiments are also contained. We include only one transition experiment to reduce the file size---the codes for all the other experiments are almost identical.

We would like to acknowledge that some routines are taken from the Numerical Recipes for Fortran 77 and some routines are given to us from Sun-Bin Kim (and possibly modified by us). All errors are ours.

